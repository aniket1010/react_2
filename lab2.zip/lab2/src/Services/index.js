import React from "react";

export default function Services(){
    return(
        <div>I am Services</div>
    );
}